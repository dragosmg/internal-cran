# packageA 0.3.1

* updated license

# packageA 0.3.0

* `add_three()`

# packageA 0.2.0

* `add_two()`

# packageA 0.1.1

* Updated the add-to-internal-cran workflow to use the GitHub Secret.

# packageA 0.1.0

* Added `add_one()` the first function.
* Added a GHA to add the package to the internal-cran.

# packageA 0.0.1

* Added a Readme file.
* Added the NEWS.md file.
* Added GHA workflows (lintr, R CMD check & test coverage).
