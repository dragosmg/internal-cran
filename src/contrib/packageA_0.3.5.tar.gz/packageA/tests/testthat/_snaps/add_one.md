# add_one() errors with non-numeric input

    `add_one()` expects a numeric input. You have supplied a character.

---

    `add_one()` expects a numeric input. You have supplied a character.

