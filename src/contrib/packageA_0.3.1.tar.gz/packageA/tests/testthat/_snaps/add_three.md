# add_three() complains with non-numeric inputs

    `add_three()` expects a numeric input. You have supplied a character.

---

    `add_three()` expects a numeric input. You have supplied a logical.

---

    `add_three()` expects a numeric input. You have supplied a character.

