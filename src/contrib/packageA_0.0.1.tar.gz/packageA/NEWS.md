# packageA 0.0.1

* Added a Readme file.
* Added the NEWS.md file.
* Added GHA workflows (lintr, R CMD check & test coverage).
