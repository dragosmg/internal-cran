# add_seven() complains with non-numeric inputs

    `add_seven()` expects a numeric input. You have supplied a character.

---

    `add_seven()` expects a numeric input. You have supplied a logical.

---

    `add_seven()` expects a numeric input. You have supplied a character.

