# add_two() complains with non-numeric inputs

    `add_two()` expects a numeric input. You have supplied a character.

---

    `add_two()` expects a numeric input. You have supplied a logical.

---

    `add_two()` expects a numeric input. You have supplied a character.

