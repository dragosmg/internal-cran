# add_eight() complains with non-numeric inputs

    `add_eight()` expects a numeric input. You have supplied a character.

---

    `add_eight()` expects a numeric input. You have supplied a logical.

---

    `add_eight()` expects a numeric input. You have supplied a character.

