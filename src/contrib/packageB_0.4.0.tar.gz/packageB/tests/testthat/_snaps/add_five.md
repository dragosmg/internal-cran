# add_five() complains with non-numeric inputs

    `add_five()` expects a numeric input. You have supplied a character.

---

    `add_five()` expects a numeric input. You have supplied a logical.

---

    `add_five()` expects a numeric input. You have supplied a character.

