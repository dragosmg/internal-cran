# add_six() complains with non-numeric inputs

    `add_six()` expects a numeric input. You have supplied a character.

---

    `add_six()` expects a numeric input. You have supplied a logical.

---

    `add_six()` expects a numeric input. You have supplied a character.

